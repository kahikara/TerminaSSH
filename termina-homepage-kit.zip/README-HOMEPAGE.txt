Termina SSH homepage kit

So nutzt du das Paket

1. Entpacke alles direkt in deinen Ordner ssh-manager
2. Dadurch bekommst du einen neuen Unterordner homepage
3. Auf GitHub im Repo unter Settings > Pages stellst du Source auf GitHub Actions
4. Danach committen und pushen

Lokaler Test

cd homepage
npm install
npm run dev

Wichtig

Die GitHub Pages URL ist aktuell auf das Repo TerminaSSH ausgelegt
Falls du den Repo Namen änderst, passe homepage/vite.config.js an
